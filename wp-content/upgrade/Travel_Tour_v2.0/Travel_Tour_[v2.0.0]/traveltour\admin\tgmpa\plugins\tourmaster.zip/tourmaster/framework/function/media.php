<?php
	/*	
	*	Tourmaster Media File
	*	---------------------------------------------------------------------
	*	This file contains media function in the theme
	*	---------------------------------------------------------------------
	*/

	// get image from image id/url
	if( !function_exists('tourmaster_get_image_url') ){
		function tourmaster_get_image_url( $image, $size = 'full', $placeholder = true){
			if( is_numeric($image) ){
				$image_src = wp_get_attachment_image_src($image, $size);
				if( !empty($image_src) ) return $image_src[0];
			}else if( !empty($image) ){
				return $image;
			}
		}
	}

	if( !function_exists('tourmaster_get_image') ){
		function tourmaster_get_image( $image, $size = 'full', $settings = array() ){

			$ret = '';

			// get_image section
			if( is_numeric($image) ){
				$alt_text = get_post_meta($image , '_wp_attachment_image_alt', true);	
				$image_src = wp_get_attachment_image_src($image, $size);

				if( !empty($image_src) ){
					$ret .= '<img src="' . esc_url($image_src[0]) . '" alt="' . esc_attr($alt_text) . '" width="' . esc_attr($image_src[1]) .'" height="' . esc_attr($image_src[2]) . '" />';
				}else{
					return;
				}
			}else if( !empty($image) ){
				$ret .= '<img src="' . esc_url($image) . '" alt="" />';
			}

			// apply link
			if( !empty($settings['link']) ){
				$ret  = '<a href="' . esc_url($settings['link']) . '" ' . 
					(empty($settings['link-target'])? '': 'target="' . esc_attr($settings['link-target']) . '"') . ' >' . $ret . '</a>';

			}

			return $ret;
		}
	}